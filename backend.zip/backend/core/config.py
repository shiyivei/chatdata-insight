from decouple import config

class Config:
         
    OPENAIAPI_KEY = config("OPENAIAPI_KEY", cast=str)
    PROMPT_FILE = config("PROMPT_FILE", cast=str)
    COIN_SYMBOLS = config("COIN_SYMBOLS", cast=str)
    # PROMPT_FILE_KAHIN = config("PROMPT_FILE_KAHIN", cast=str)
    NEWS_API_KEY = config("NEWS_API_KEY", cast=str)
    QUICKNODE_ENDPOINT = config("QUICKNODE_ENDPOINT", cast=str)
    QUICKNODE_API_KEY = config("QUICKNODE_API_KEY", cast=str)
    JUDGEMENT_PROMPT = config("JUDGEMENT_PROMPT", cast=str)